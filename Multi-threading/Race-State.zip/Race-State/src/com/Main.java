package com;

public class Main {

    public static void main(String[] args) {
	Counter c = new Counter();
	c.addAndSubtract();

    }
}
