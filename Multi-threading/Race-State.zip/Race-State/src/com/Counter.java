package com;

public class Counter {

    private int total = 0;

    public void addAndSubtract(){
        Thread t1 = new Thread(new Runnable() {

            public void run() {
            for (int i = 0; i <10000; i++){
                     add();
                 }
            }
        });
        Thread t2 = new Thread(new Runnable() {

            public void run() {
                for (int i = 0; i <10000; i++){
                    subtract();
                }
            }
        });

        t1.start();
        t2.start();

        try {
            t1.join();
            t2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("The total is now " + total);
    }

    public void add(){
        total++;
    }

    public void subtract(){
        total--;
    }
}
